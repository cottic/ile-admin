self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8c05fddeedde2b072fbc6cc07049116c",
    "url": "./index.html"
  },
  {
    "revision": "a4c80f7d40a0f6076990",
    "url": "./static/js/2.8d9dee9f.chunk.js"
  },
  {
    "revision": "0ebbe599bcd93080b3103b558899ee29",
    "url": "./static/js/2.8d9dee9f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "be9c619ddf37472351f3",
    "url": "./static/js/main.36a18e34.chunk.js"
  },
  {
    "revision": "e731c8278f32f4fef3f8",
    "url": "./static/js/runtime-main.423bca75.js"
  }
]);