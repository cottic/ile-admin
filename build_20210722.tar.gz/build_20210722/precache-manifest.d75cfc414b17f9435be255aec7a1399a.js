self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cff67b429b44632f19b5203d3c0a8694",
    "url": "./index.html"
  },
  {
    "revision": "a4c80f7d40a0f6076990",
    "url": "./static/js/2.8d9dee9f.chunk.js"
  },
  {
    "revision": "0ebbe599bcd93080b3103b558899ee29",
    "url": "./static/js/2.8d9dee9f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c9ac0ab0d8260a507a5b",
    "url": "./static/js/main.55ae65df.chunk.js"
  },
  {
    "revision": "e731c8278f32f4fef3f8",
    "url": "./static/js/runtime-main.423bca75.js"
  }
]);